clear
clc
A=[2 1 5 3 4];
B=[1 5 3 4 2];
C=[4 1 2 3 5];
D=[1 4 2 3 5];
E=[5 4 3 1 2];
neighbork=[A;B;C;D;E];

center_route=Center(neighbork);