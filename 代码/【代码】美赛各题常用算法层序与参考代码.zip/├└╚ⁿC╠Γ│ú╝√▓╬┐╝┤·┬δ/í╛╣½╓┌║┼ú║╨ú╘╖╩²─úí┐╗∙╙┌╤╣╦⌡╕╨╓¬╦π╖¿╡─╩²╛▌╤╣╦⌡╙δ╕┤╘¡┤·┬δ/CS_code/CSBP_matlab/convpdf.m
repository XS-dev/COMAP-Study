function c=convpdf(a,b)

c=conv(a,b);
