function op=reverse(ip, m)

op=[ip(1) ip(m:-1:2)];
