% Dimensionality Reduction Toolbox
% Version 0.7.1b 25-June-2010